package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"strings"
	"time"

	sdkArgs "github.com/newrelic/infra-integrations-sdk/args"
	"github.com/newrelic/infra-integrations-sdk/log"
	"github.com/newrelic/infra-integrations-sdk/metric"
	"github.com/newrelic/infra-integrations-sdk/sdk"
	"github.com/spf13/viper"
)

type argumentList struct {
	sdkArgs.DefaultArgumentList
}

// Defines the struct that holds config info about the Apigee environment
// This is filled in by nr-apigee_metrics-settings.yml.
type configStruct struct {
	ProxyURL  string   `yaml:"proxyURL"`
	TimeRange int      `yaml:"timeRange"`
	Dimension string   `yaml:"dimension"`
	Queries   []string `yaml:"queries"`
	Apigee    struct {
		Orgs []struct {
			Org      string   `yaml:"org"`
			UserID   string   `yaml:"userID"`
			Password string   `yaml:"password"`
			Envs     []string `yaml:"envs"`
		} `yaml:"orgs"`
	} `yaml:"apigee"`
}

// Define the struct that holds the performance data returned by Apigee when we query.
// Apigee returns numbers as strings, so we need to define Metrics.Values as []json.Number so the
// JSON package unmarshal function recasts them as numbers.  Otherwise we get strings in Insights and that's bad.
type apigeeJSONstr struct {
	Environments []struct {
		Dimensions []struct {
			Metrics []struct {
				Name   string        `json:"name"`
				Values []json.Number `json:"values"`
			} `json:"metrics"`
			Name string `json:"name"`
		} `json:"dimensions"`
		Name string `json:"name"`
	} `json:"environments"`
	MetaData struct {
		Errors  []interface{} `json:"errors"`
		Notices []string      `json:"notices"`
	} `json:"metaData"`
}

const (
	integrationName    = "com.New-Relic.apigee_metrics"
	integrationVersion = "0.3.3"
)

var args argumentList
var configData configStruct

// Nothing to see here, move along.
func populateInventory(inventory sdk.Inventory) error {
	// Insert here the logic of your integration to get the inventory data
	// Ex: inventory.SetItem("softwareVersion", "value", "1.0.1")
	// --
	log.Debug("Somehow, we've ended up in populateInventory - this is completely unexpected.")
	return nil
}

func populateMetrics(integration *sdk.Integration, apigeeJSON apigeeJSONstr, apigeeOrg string) error {
	log.Debug("Beginning populate metrics.")
	for _, environment := range apigeeJSON.Environments {
		for _, dimension := range environment.Dimensions {
			log.Debug("Processing - Org : " + apigeeOrg + ", Env : " + environment.Name + ", Dim : " + dimension.Name)
			ms := integration.NewMetricSet("NrApigee_metricsSample")
			ms.SetMetric("ApigeeOrg", apigeeOrg, metric.ATTRIBUTE)
			ms.SetMetric("ApigeeEnv", environment.Name, metric.ATTRIBUTE)
			ms.SetMetric("ApigeeProxyName", dimension.Name, metric.ATTRIBUTE)

			for _, apigeeMetric := range dimension.Metrics {
				//log.Debug("Metric Name : " + apigeeMetric.Name + " = " + apigeeMetric.Values[0])
				log.Debug("Metric Name : %s = %s", apigeeMetric.Name, apigeeMetric.Values[0])
				ms.SetMetric(apigeeMetric.Name, apigeeMetric.Values[0], metric.GAUGE)
			}
		}
	}
	return nil
}

//Apigee specific helper functions defined below.
func readConfig() {
	log.Debug("In readConfig")
	viper.SetConfigName("nr-apigee_metrics-settings")
	viper.AddConfigPath(".")
	err := viper.ReadInConfig()
	if err != nil {
		panic(fmt.Errorf("Fatal error config file: %s \n", err))
	}
	err = viper.Unmarshal(&configData)
	if err != nil {
		panic(fmt.Errorf("Fatal error config unmarshal: %s \n", err))
	}
}

// Build the query we're going to send to Apigee's RESTful interface.
func buildApigeeMetricQuery(apigeeOrg string, apigeeEnv string, apigeeTotalQuery string, apigeeDimension string, apigeeTimeRange time.Duration) string {
	log.Debug("In buildApigeeMetricQuery")
	var apigeeBaseURL string = "https://api.enterprise.apigee.com/v1/organizations"

	//Apigee requires time specificed in UTC. Their docs say that data can take up to 10 minutes to post, so (to be safe)
	// we are looking back 15 minutes and getting 5 minute aggregates.
	// We multiply by -1 because the function is adding, not subtracting.
	var now = time.Now().UTC()
	var timeRangeStart = now.Add(time.Minute * -15)
	var timeRangeEnd = timeRangeStart.Add(time.Minute*-1 + apigeeTimeRange)

	//I'm sure I could do something fancy with the URL module, but for now, I'm doing this.
	var timeRange = strings.Replace(timeRangeStart.Format("01/02/2006 15:04")+"~"+timeRangeEnd.Format("01/02/2006 15:04"), " ", "%20", -1)
	var apigeeURL = apigeeBaseURL + "/" + apigeeOrg + "/environments/" + apigeeEnv + "/stats/" + apigeeDimension + "?" + apigeeTotalQuery + "&timeRange=" + timeRange
	log.Debug("Apigee URL : %s", apigeeURL)

	return apigeeURL
}

//Query Apigee for the list of environments associated with the org.
func buildApigeeEnvQuery(apigeeOrg string) string {
	log.Debug("In buildAPigeeEnvQuery")
	log.Debug("Building query for environment: %s", apigeeOrg)
	apigeeBaseURL := "https://api.enterprise.apigee.com/v1/organizations"
	apigeeEnvURL := apigeeBaseURL + "/" + apigeeOrg + "/environments"
	log.Debug("Environment query URL: %s", apigeeEnvURL)

	return apigeeEnvURL
}

// Send the query we built to Apigee and capture the result.
func executeApigeeQuery(apigeeURL string, apigeeUser string, apigeePass string) []byte {
	log.Debug("In executeApigeeQuery")
	client := &http.Client{}
	req, err := http.NewRequest("GET", apigeeURL, nil)
	req.SetBasicAuth(apigeeUser, apigeePass)
	resp, err := client.Do(req)

	if err != nil {
		log.Fatal(err)
	}

	//fmt.Println(resp.Status)
	log.Debug("Response: " + resp.Status)

	page, err := ioutil.ReadAll(resp.Body)
	//fmt.Println("Page: \n")
	//fmt.Printf("%s\n\n", page)

	return page
}

// Process the returned JSON query result into an object
func processApigeeJSON(apigeeResp []byte) apigeeJSONstr {
	log.Debug("In processsApigeeJSON")
	var apigeeJSON apigeeJSONstr
	if err := json.Unmarshal(apigeeResp, &apigeeJSON); err != nil {
		panic(fmt.Errorf("Fatal error processing Apigee JSON: %s \n", err))
	}
	return apigeeJSON
}

func main() {
	//Initialize some variables
	var apigeeMetricURL string
	var apigeeResp []byte
	var apigeeJSON apigeeJSONstr
	var apigeeTotalQuery string
	var apigeeEnvs []string

	integration, err := sdk.NewIntegration(integrationName, integrationVersion, &args)
	fatalIfErr(err)

	log.Debug("Starting Up - version: " + integrationVersion)

	//Get the configuration data about the Apigee instance we're going to query.
	readConfig()

	var apigeeDimension string = configData.Dimension
	var apigeeTimeRange = time.Duration(configData.TimeRange) * time.Minute
	var ProxyURL string = configData.ProxyURL

	log.Debug("Configuration has been read in.")
	log.Debug("Proxy URL: %s", ProxyURL)
	log.Debug("Apigee Dimension: %s", apigeeDimension)
	log.Debug("Apigee Time Range: %s", apigeeTimeRange)

	//If a proxyURL is configured, set the appropriate environment variable
	if ProxyURL != "" {
		log.Debug("Proxy setting detected. Configuring OS environment.")
		os.Setenv("HTTP_PROXY", ProxyURL)
	}

	//We can pass all of our queries at once to Apigee - we'll see how big a mess this makes
	apigeeTotalQuery = "select=" + strings.Join(configData.Queries, ",")
	log.Debug("Apigee Total Query =" + apigeeTotalQuery)

	if args.All || args.Inventory {
		//fatalIfErr(populateInventory(integration.Inventory))
	}

	log.Debug("Ready to poll Apigee")
	if args.All || args.Metrics {
		for _, apigeeOrg := range configData.Apigee.Orgs {
			apigeeEnvURL := buildApigeeEnvQuery(apigeeOrg.Org)
			apigeeEnvsResp := executeApigeeQuery(apigeeEnvURL, apigeeOrg.UserID, apigeeOrg.Password)
			log.Debug("Org: %s has environments: %s", apigeeOrg.Org, apigeeEnvsResp)
			json.Unmarshal(apigeeEnvsResp, &apigeeEnvs)
			for _, apigeeEnv := range apigeeEnvs {
				log.Debug("Asking for - Org : " + apigeeOrg.Org + ", Env : " + apigeeEnv + ", Dim : " + apigeeDimension + ", Time Range : " + apigeeTimeRange.String())
				apigeeMetricURL = buildApigeeMetricQuery(apigeeOrg.Org, apigeeEnv, apigeeTotalQuery, apigeeDimension, apigeeTimeRange)
				apigeeResp = executeApigeeQuery(apigeeMetricURL, apigeeOrg.UserID, apigeeOrg.Password)
				apigeeJSON = processApigeeJSON(apigeeResp)
				fatalIfErr(populateMetrics(integration, apigeeJSON, apigeeOrg.Org))
			}
		}
	}
	log.Debug("Publishing")
	fatalIfErr(integration.Publish())
}

func fatalIfErr(err error) {
	if err != nil {
		log.Debug("Fatal if error triggered.")
		log.Fatal(err)
	}
}
