#!/bin/bash
env GOOS=darwin GOARCH=amd64 go build -o nr-apigee_metrics.mac nr-apigee_metrics.go
env GOOS=linux GOARCH=amd64 go build -o nr-apigee_metrics.linux nr-apigee_metrics.go
env GOOS=windows GOARCH=amd64 go build nr-apigee_metrics.go 
