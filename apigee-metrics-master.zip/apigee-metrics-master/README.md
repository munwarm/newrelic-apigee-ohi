#apigee-metrics

This New Relic Infrastructure on-host integration polls the Apigee RESTful API for performance metrics and inserts them into New Relic Insights for use in dashboards and such.

It uses the New Relic integrations SDK, documented at: https://docs.newrelic.com/docs/integrations/integrations-sdk.

To use this integration, do the following:
1. Install a New Relic Infrastructure agent on a host that can reach your Apigee installation.
2. Install the New Relic Apigee plugin as documented here: https://docs.newrelic.com/docs/integrations/integrations-sdk/getting-started/integration-file-structure-activation
3. In the same directory as the integration's binary, create a file called nr-apigee_metrics-settings.yml and edit it per the docs in the template.
4. Let the agent run the integration and look for data in Insights.

The installApigee.sh installer script should automate the above for Mac or Linux platforms.  Download the files in this repository into a directory onto a server that is running the NR Infra agent.  Then make the script executable and run it.

Some helpful Apigee pages:

https://docs.apigee.com/analytics-services/content/use-analytics-api-measure-api-program-performance
https://docs.apigee.com/analytics-services/reference/analytics-reference
https://docs.apigee.com/management/apis/get/organizations/%7Borg_name%7D/environments/%7Benv_name%7D/stats/%7Bdimension_name%7D-0


A note on timeframes -

Apigee's docs say: "After API calls are made to proxies, it takes about 12 minutes for the data to appear in dashboards, custom reports, and management API calls."

So, in order to handle that, we have hard coded a 15 minute look back interval.  This interacts with the timeRange setting in nr-apigee_metrics-settings.yml file to average metrics over a timeframe.  When the integration polls, it asks for a single data point with all data from (now - 15 minutes) to (now - 15 minutes - timeRange).  The type of data returned will depend on the aggregation function used in the query.

Consider the following example:  
The wall clock says it's 11:30 and timeRange is set to 5.  The integration is going to poll for sum(message_count) and avg(total_response_time).

In this case, Apigee will return the total number of Apigee messages sent between 11:10 (now - 15 minutes - timeRange) and 11:15 (now - 15 minutes).  Apigee will also gather the response times of all API responses sent between 11:10 and 11:15 and create a single 5 minute average.  Those two datapoints will be returned and be sent to Insights.

This integration does no mathmatical processing of the metrics, it gathers them from Apigee and forwards them to Insights.

Please also note that the out of box execution interval of the integration is 300 seconds (aka 5 minutes). If you change timeRange, you'll also need to change the execution interval in nr-apigee_metrics-definition.yml, otherwise you're going to get silly results.
