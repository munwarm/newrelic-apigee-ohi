#!/bin/bash

exeLoc="/var/db/newrelic-infra/custom-integrations"
configLoc="/etc/newrelic-infra/integrations.d"

if [[ "$OSTYPE" == "linux-gnu" ]]; then
        echo "Linux OS detected"
        cp ./nr-apigee_metrics.linux ./nr-apigee_metrics
elif [[ "$OSTYPE" == "darwin"* ]]; then
        echo "Mac OS detected"
        cp .nr-apigee_metrics.mac ./nr-apigee_metrics
else
        echo "FATAL: $OSTYPE is an unknown OS type."
fi

cp nr-apigee_metrics $exeLoc
cp nr-apigee_metrics-definition.yml $exeLoc
cp nr-apigee_metrics-settings.yml $exeLoc
cp nr-apigee_metrics_settings.yml.template $exeLoc
cp nr-apigee_metrics-config.yml $configLoc
